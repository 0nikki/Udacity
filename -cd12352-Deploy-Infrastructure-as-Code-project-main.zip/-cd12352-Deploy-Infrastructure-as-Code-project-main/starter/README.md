# CD12352 - Infrastructure as Code Project Solution
# [YOUR NAME HERE]

## Spin up instructions
TODO

## Tear down instructions
TODO

## Other considerations
TODO (optional)